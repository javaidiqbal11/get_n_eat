package com.example.getneat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
