## [1.0.0] - October 4, 2022

* Initial support so Flutter apps that run on Windows won't encounter errors. Visibility is returned as false.